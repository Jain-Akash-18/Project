package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest

public class IpTreatmentWebPortalApplicationTests {

	@Test
	public void contextLoads() {
	}


	@Test
	public void applicationStarts() {
		IpTreatmentWebPortalApplication.main(new String[] {});
	}
}
