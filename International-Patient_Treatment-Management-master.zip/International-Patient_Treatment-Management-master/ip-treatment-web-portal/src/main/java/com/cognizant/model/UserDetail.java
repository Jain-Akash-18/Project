package com.cognizant.model;

/**
 * 
 * @author Pratik, Shubham, Pratik, Kavya
 * 
 * 		model class for UserDetails
 * 
 *     
 *
 */
public class UserDetail {
	
	@SuppressWarnings("unused")
	private String name;
}
